﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gumruk
{
    public partial class Filtrele : Form
    {
        public Filtrele()
        {
            InitializeComponent();
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            string aramaTerimi = txtArama.Text.Trim(); // TextBox'tan arama terimini alın
            ListeleUrunler(aramaTerimi);
        }

        private void ListeleUrunler(string aramaTerimi = "")
        {
            using (GumrukContext db = new GumrukContext())
            {
                var urunler = db.Ürünler.AsQueryable();

                if (!string.IsNullOrEmpty(aramaTerimi))
                {
                    urunler = urunler.Where(x => x.Ad.Contains(aramaTerimi));
                }

                dataGridView1.DataSource = urunler.ToList();
            }
        }

        private void Filtrele_Load(object sender, EventArgs e)
        {
            ListeleUrunler();
        }
    }
}
