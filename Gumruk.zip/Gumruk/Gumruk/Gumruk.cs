﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gumruk
{
    public partial class Gumruk : Form
    {
        public Gumruk()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=GumrukDB;Integrated Security=SSPI");
        SqlCommand command;
        SqlDataAdapter da;
        DialogResult dialog = new DialogResult();

        void DataShow()
        {
            SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=GumrukDB;Integrated Security=SSPI");
            baglanti.Open();
            da = new SqlDataAdapter("SELECT *FROM Ürünler", baglanti);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
            baglanti.Close();
        }

        private void Gumruk_Load(object sender, EventArgs e)
        {
            dtpduedate.Format = DateTimePickerFormat.Custom;
            dtpduedate.CustomFormat = "yyyy-MM-dd";
        }

        private void btnlistele_Click(object sender, EventArgs e)
        {
            DataShow();
            //dialog = MessageBox.Show("Ürünler  Listeleniyor ! ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toolStripStatusLabel1.Text = "Ürünler  Listeleniyor !";
            statusStrip1.Refresh();
            Application.DoEvents();
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            string sorgu1 = "INSERT INTO Ürünler(Ad,Fiyat,Ülke,İşlem_Tarihi,Notlar) VALUES (@Ad,@Fiyat,@Ülke,@İşlem_Tarihi,@Notlar)";
            command = new SqlCommand(sorgu1, baglanti);
            command.Parameters.AddWithValue("@Ad", txtad.Text);
            command.Parameters.AddWithValue("@Fiyat", txtfiyat.Text);
            command.Parameters.AddWithValue("@Ülke", txtülke.Text);
            command.Parameters.AddWithValue("@İşlem_Tarihi", dtpduedate.Value);
            command.Parameters.AddWithValue("@Notlar", rtbtask.Text);
            baglanti.Open();
            command.ExecuteNonQuery();
            baglanti.Close();
            DataShow();
            //dialog = MessageBox.Show("Ürün Başarılı Bir Şekilde Eklendi ! ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toolStripStatusLabel1.Text = "Ürün Başarılı Bir Şekilde Eklendi !";
            statusStrip1.Refresh();
            Application.DoEvents();
        }

        private void btndüzenle_Click(object sender, EventArgs e)
        {
            string sorgu = "UPDATE Ürünler SET Ad = @Ad,Fiyat = @Fiyat,Ülke = @Ülke,İşlem_Tarihi=@İşlem_Tarihi,Notlar = @Notlar  WHERE ID = @ID";
            command = new SqlCommand(sorgu, baglanti);
            command.Parameters.AddWithValue("@ID", Convert.ToInt32(txtid.Text));
            command.Parameters.AddWithValue("@Ad", txtad.Text);
            command.Parameters.AddWithValue("@Fiyat", txtfiyat.Text);
            command.Parameters.AddWithValue("@Ülke", txtülke.Text);
            command.Parameters.AddWithValue("@İşlem_Tarihi", dtpduedate.Value);
            command.Parameters.AddWithValue("@Notlar", rtbtask.Text);
            baglanti.Open();
            command.ExecuteNonQuery();
            baglanti.Close();
            DataShow();
            //dialog = MessageBox.Show("Ürün Başarılı Bir Şekilde Güncellendi ! ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toolStripStatusLabel1.Text = "Ürün Başarılı Bir Şekilde Güncellendi !";
            statusStrip1.Refresh();
            Application.DoEvents();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string sorgu = "DELETE FROM Ürünler WHERE ID=@ID";
            command = new SqlCommand(sorgu, baglanti);
            command.Parameters.AddWithValue("@ID", Convert.ToInt32(txtid.Text));
            baglanti.Open();
            command.ExecuteNonQuery();
            baglanti.Close();
            DataShow();
            //dialog = MessageBox.Show("Ürün Başarılı Bir Şekilde Silindi ! ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toolStripStatusLabel1.Text = "Ürün Başarılı Bir Şekilde Silindi !";
            statusStrip1.Refresh();
            Application.DoEvents();
        }

        private void btntemizle_Click(object sender, EventArgs e)
        {
            foreach (Control item in groupBox1.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
                if (item is RichTextBox)
                {
                    item.Text = "";
                }
                if (item is DateTimePicker)
                {
                    item.ResetText();
                }
                if (item is ComboBox)
                {
                    item.Text = "";
                }
                if (item is NumericUpDown)
                {
                    item.Text = "";
                }
            }
            dialog = MessageBox.Show("Bütün Yazılar Temizlendi ! ", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtad.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtfiyat.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtülke.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            dtpduedate.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            rtbtask.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void txtfiltreleme_Click(object sender, EventArgs e)
        {
            Filtrele filtrele = new Filtrele();
            filtrele.Show();
            filtrele.Location = new Point(-11, 46);
        }
    }
}
