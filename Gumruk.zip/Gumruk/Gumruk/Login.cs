﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gumruk
{
    public partial class YeniKullanici : Form
    {
        public YeniKullanici()
        {
            InitializeComponent();
            panel1.BackColor = System.Drawing.Color.FromArgb(100, 0, 0, 0);
        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            string connectionString = "server=.;Initial Catalog=GumrukDB;Integrated Security=SSPI";
            string verify = "19052000";

            if (txtpassword.Text == txtrepassword.Text)
            {
                if (txtverify.Text == verify)
                {
                    using (SqlConnection baglanti = new SqlConnection(connectionString))
                    {
                        baglanti.Open();
                        using (SqlCommand command = new SqlCommand("insert into Kullanıcılar (Username,Password) values (@Username, @Password)", baglanti))
                        {
                            command.Parameters.AddWithValue("@Username", txtusername.Text);
                            command.Parameters.AddWithValue("@Password", txtpassword.Text);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Kayıt işlemi başarı ile gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    DialogResult dialog = MessageBox.Show("Referans Kodunu Kontrol Ediniz ! ", "Hata", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Cancel)
                    {
                        Application.Exit();
                    }
                }
            }
            else
            {
                DialogResult dialog = MessageBox.Show("Şifreler Birbirleri ile Uyuşmuyor ! ", "Hata", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Cancel)
                {
                    Application.Exit();
                }
            }
        }
    }
}
